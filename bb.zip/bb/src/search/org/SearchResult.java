package search.org;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.util.*;

public class SearchResult {

	private static String  productKey = "f5mnq7nk82v6356bvpaqf6sc";
	private static Scanner scanner;	
	
	public static void main(String[] args) {

		gettheInputfromScreen();
	}
	
	/**
	 * This method calling all other methods in sequence
	 * @param NA
	 * @return NA
	 */
	
	public static void gettheInputfromScreen(){
		
		SearchResult searchResults = new SearchResult();
		String productName = searchResults.getEnteredString();
		Integer firstResultforProduct =  searchResults.getFirstResultforProduct(productName);
		searchResults.getRecommendationsforProduct(firstResultforProduct);
		
	}
	
	/**
	 * This method to read the String which is entered by User
	 * @param 
	 * @return String return the product name 
	 */
	
	private String getEnteredString() {

		scanner = new Scanner(System.in);
        String productName;
        System.out.println("Enter Product Name to search and get recommendaded results");
        productName=(scanner.next());
        return productName;
   
	}
	
	/**
	 * This method get all the search results for entered String
	 * @param String product name which user wants to search
	 * @return First Product ID from the search result
	 */
	
	private Integer getFirstResultforProduct(String productName) {

		//create a client		
		Client client = ClientBuilder.newClient() ;
		int resultItem = 0; 
		String resultItemName = "";
		
		//give the URI
        String URIforProductSearch = "http://api.walmartlabs.com/v1/search?apiKey=" + productKey + "&lsPublisherId=parth&query=" + productName; 		
		WebTarget target =  client.target(URIforProductSearch);
		
		//Converting into String
		String jsonString  = target.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(String.class);
		JSONObject json = new JSONObject(jsonString);
		LinkedHashMap<Integer,String> productSearchMapName = new LinkedHashMap<Integer,String>();

		try {
			
			//checking for item
			JSONArray arryOfItems = json.getJSONArray("items");
			
			//Parse all the items and get all itemId and itemName		 
			System.out.println("First Product Name and itemId from the result search:- ");
			for (int i = 0; i < arryOfItems.length(); i++)
			{
			    int post_id = arryOfItems.getJSONObject(i).getInt("itemId");	
			    String post_name = arryOfItems.getJSONObject(i).getString("name");
			    productSearchMapName.put(post_id,post_name);
			}
		
		}catch(JSONException jasonExp){
			System.out.println("Search Result is not avalable for your entred product. Please search for different product than:- " + productName );
			gettheInputfromScreen();
		}
		
		if(!productSearchMapName.isEmpty()){
			
			resultItem = (int) productSearchMapName.keySet().toArray()[0];
			resultItemName = productSearchMapName.get(resultItem);
		}

		System.out.println(resultItemName+"[" +resultItem +"]");	
			return resultItem;
	}
	
	/**
	 * This method display all top 10 Recommendations
	 * These Recommendations sort based on average ratings of that product
	 * If Statistics are not available then it shoe message that ratings are not available
	 * @param Integer First productId from the search result
	 * @return
	 */
	
	
	private void getRecommendationsforProduct(Integer firstResultforProduct ) {

			Client client2 = ClientBuilder.newClient() ;
			String URIRecommendationSearch = "http://api.walmartlabs.com/v1/nbp?apiKey="+productKey+"&itemId=" + firstResultforProduct ;
			 
			WebTarget target2 = client2.target(URIRecommendationSearch);

			String jsonString2  = target2.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(String.class);
			
			JSONArray jsonArray2 = new JSONArray(jsonString2);
			
			
			ArrayList<Integer> recommendedItemIds = new ArrayList<Integer>();
			ArrayList<Double> reviewsArry = new ArrayList<Double>();
			HashMap<Integer,Double> reviewMap = new HashMap<Integer,Double>();
			HashMap<Integer,String> reviewMapName = new HashMap<Integer,String>();
			
			System.out.println("");
			System.out.println("Getting recommendation items for ItemId:" +firstResultforProduct);
			int itemId = 0 ;
			
			
			for(int i=0; i<10 ;i++){

				try {
					JSONObject jsonObj = jsonArray2.getJSONObject(i);
					itemId = jsonObj.getInt("itemId");
					recommendedItemIds.add(itemId);
					WebTarget target3 = 
							client2.target("http://api.walmartlabs.com/v1/reviews/"+itemId+"?apiKey="+productKey+"&lsPublisherId=&format=json");

					String jsonString3  = target3.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(String.class);

					//reviewStatistics
					JSONObject myObject = new JSONObject(jsonString3);

					JSONObject reviewStaticsObj = myObject.getJSONObject("reviewStatistics");
					
					int itemIdObj = myObject.getInt("itemId");	  
					
					String itemName = myObject.getString("name");
					
					double averageOverallRating =  reviewStaticsObj.getDouble("averageOverallRating");
					
					reviewMapName.put(itemIdObj, itemName);
					reviewMap.put(itemIdObj, averageOverallRating);
					
					reviewsArry.add(averageOverallRating);
				}catch(JSONException jasonExp){			
					
					if(jasonExp.getMessage().equals("JSONArray[0] not found.") ){
						System.out.println("Recommendations are not avalable.");
						
					}else {
						System.out.println("Average Review Ratings are not available for Recommended itemId: " + itemId );
					}
				}

			}
			Map<Integer,Double> sortedMap = sortByComparator(reviewMap);
			DecimalFormat formatter = new DecimalFormat("#0.00");

			System.out.println(); 
			System.out.println(  sortedMap.size() + " Recommended items with Average Rating in sorted order :-"); 
			System.out.println(  "--------------------------------------------" );
			System.out.println("| Product Name(ProductId) => Average Rating |"); 
			System.out.println(  "--------------------------------------------");
			
			int i =1;		
			for (Map.Entry<Integer,Double> entry : sortedMap.entrySet()) {
			    System.out.println( "("+i+")" + "|  "+reviewMapName.get(entry.getKey()) + "["+ entry.getKey() + "]  ----->    "+ formatter.format(entry.getValue()) );
			    i++;
					}

			System.out.println(  "---------------------------------------------");
			Runtime.getRuntime().exit(0);
			
		}
			
	/**
	 * This method sorts the map based on the review ratings
	 * @param unsortMap
	 * @return
	 */
	
	private static Map<Integer,Double> sortByComparator(Map<Integer,Double> unsortMap) {

		// Convert Map to List
		List<Map.Entry<Integer,Double>> list = 
			new LinkedList<Map.Entry<Integer,Double>>(unsortMap.entrySet());

		// Sort list with comparator, to compare the Map values
		Collections.sort(list, new Comparator<Map.Entry<Integer,Double>>() {
			public int compare(Map.Entry<Integer,Double> o1,
                                           Map.Entry<Integer,Double> o2) {
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});

		// Convert sorted map back to a Map
		Map<Integer,Double> sortedMap = new LinkedHashMap<Integer,Double>();
		
		for (Iterator<Map.Entry<Integer,Double>> it = list.iterator(); it.hasNext();) {
			Map.Entry<Integer,Double> entry = it.next();
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		return sortedMap;
	}
}

